from gym_inventory.envs.staking_env import StakingEnv
